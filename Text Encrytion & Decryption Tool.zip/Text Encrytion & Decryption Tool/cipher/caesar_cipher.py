# ---------------- Cipher Strategy Base Class ----------------
class CipherStrategy:
    def encrypt(self, text):
        raise NotImplementedError("Encrypt method must be overridden.")

    def decrypt(self, text):
        raise NotImplementedError("Decrypt method must be overridden.")

# ---------------- Caesar Cipher Implementation ----------------
class CaesarCipher(CipherStrategy):
    def __init__(self, shift):
        self.shift = shift

    def encrypt(self, text):
        return self._transform(text, self.shift)

    def decrypt(self, text):
        return self._transform(text, -self.shift)

    def _transform(self, text, shift):
        result = ""
        for char in text:
            if char.isalpha():
                base = ord('A') if char.isupper() else ord('a')
                shifted = chr((ord(char) - base + shift) % 26 + base)
                result += shifted
            else:
                result += char
        return result
