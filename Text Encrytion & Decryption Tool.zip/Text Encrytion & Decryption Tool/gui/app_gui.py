import tkinter as tk
from tkinter import ttk, messagebox

class CaesarCipherGUI:
    def __init__(self, root, cipher):
        self.root = root
        self.cipher = cipher
        self.root.title("Text Encryption & Decryption Tool")
        self.root.geometry("550x540")
        self.root.configure(bg="#0f0f0f")
        self.root.resizable(False, False)
        self._create_widgets()

    def _create_widgets(self):
        tk.Label(self.root, text="Text Encryption & Decryption Tool",
                 font=("Helvetica", 20, "bold"), fg="#39ff14", bg="#0f0f0f").pack(pady=15)

        ttk.Label(self.root, text="Select Action:").pack(pady=5)
        self.action_combo = ttk.Combobox(self.root, values=["Encrypt", "Decrypt"], state="readonly")
        self.action_combo.current(0)
        self.action_combo.pack()

        ttk.Label(self.root, text="Enter your message:").pack(pady=5)
        self.message_entry = tk.Text(self.root, height=5, width=55)
        self.message_entry.pack(pady=5)

        ttk.Label(self.root, text="Enter Shift Value (1-25):").pack(pady=5)
        self.shift_entry = ttk.Entry(self.root, width=30)
        self.shift_entry.pack(pady=5)

        tk.Label(self.root, text="", bg="#0f0f0f").pack()
        ttk.Button(self.root, text="Process", command=self._process_text).pack(pady=15)

        ttk.Label(self.root, text="Result:").pack(pady=5)
        self.output_text = tk.Text(self.root, height=6, width=55, state="disabled",
                                   bg="#1c1c1c", fg="#39ff14", insertbackground="white")
        self.output_text.pack(pady=5)

        description = (
            "This tool uses the Caesar Cipher technique.\n"
            "Each letter is shifted by a fixed number of positions.\n"
            "You can adjust the shift using the input above."
        )
        tk.Label(self.root, text=description, font=("Arial", 10), fg="#888", bg="#0f0f0f").pack(pady=10)

        tk.Label(self.root, text="Created by Irfan – OOP Caesar Cipher Tool",
                 font=("Arial", 8), fg="#555", bg="#0f0f0f").pack(pady=10)

    def _process_text(self):
        action = self.action_combo.get()
        message = self.message_entry.get("1.0", "end-1c").strip()
        shift_value = self.shift_entry.get().strip()

        if not message:
            messagebox.showwarning("Input Error", "Please enter a message.")
            return
        if not shift_value:
            messagebox.showwarning("Input Error", "Please enter a shift value.")
            return

        try:
            shift = int(shift_value)
            if shift < 1 or shift > 25:
                raise ValueError
        except ValueError:
            messagebox.showerror("Invalid Input", "Shift must be a number between 1 and 25.")
            return

        self.cipher.shift = shift
        result = self.cipher.encrypt(message) if action == "Encrypt" else self.cipher.decrypt(message)

        self.output_text.config(state="normal")
        self.output_text.delete("1.0", "end")
        self.output_text.insert("1.0", result)
        self.output_text.config(state="disabled")
