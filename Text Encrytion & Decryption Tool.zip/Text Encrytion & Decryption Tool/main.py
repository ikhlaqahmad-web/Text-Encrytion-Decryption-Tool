from cipher.caesar_cipher import CaesarCipher
from gui.app_gui import CaesarCipherGUI
import tkinter as tk

if __name__ == "__main__":
    root = tk.Tk()
    cipher = CaesarCipher(shift=3)  # Default shift; will be updated by user input in GUI
    app = CaesarCipherGUI(root, cipher)
    root.mainloop()
